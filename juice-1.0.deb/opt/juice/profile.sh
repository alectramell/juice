#!/bin/bash

clear

rm /opt/juice/list.txt

clear

wget --no-check-certificate -O /opt/juice/list.txt --quiet https://raw.githubusercontent.com/alectramell/juice/master/list.txt

clear

PROFILE="bronze"
